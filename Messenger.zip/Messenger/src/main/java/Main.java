import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/user")
public class UserServlet extends HttpServlet {

    private DatabaseHandler dbHandler = DatabaseHandler.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (dbHandler.isUserExists(username)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("User already exists");
        } else {
            dbHandler.registerUser(username, password);
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("User registered successfully");
        }
    }
}

@WebServlet("/message")
public class MessageServlet extends HttpServlet {

    private DatabaseHandler dbHandler = DatabaseHandler.getInstance();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String message = request.getParameter("message");

        if (message.contains("\n") || !dbHandler.isUserExists(username)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("Invalid message or user");
        } else {
            dbHandler.sendMessage(username, message);
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("Message sent successfully");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (dbHandler.authenticateUser(username, password)) {
            String messages = dbHandler.getUserMessages(username);
            response.setContentType("application/json");
            response.getWriter().write(messages);
        } else {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("Invalid credentials");
        }
    }
}

class DatabaseHandler {
    private static DatabaseHandler instance;
    private Connection connection;

    private DatabaseHandler() {
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/messenger", "user", "password");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static synchronized DatabaseHandler getInstance() {
        if (instance == null) {
            instance = new DatabaseHandler();
        }
        return instance;
    }

    public boolean isUserExists(String username) {
        try (PreparedStatement stmt = connection.prepareStatement("SELECT 1 FROM users WHERE username = ?")) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void registerUser(String username, String password) {
        try (PreparedStatement stmt = connection.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)");) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(String username, String message) {
        try (PreparedStatement stmt = connection.prepareStatement("INSERT INTO messages (username, message) VALUES (?, ?)");) {
            stmt.setString(1, username);
            stmt.setString(2, message);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean authenticateUser(String username, String password) {
        try (PreparedStatement stmt = connection.prepareStatement("SELECT 1 FROM users WHERE username = ? AND password = ?")) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getUserMessages(String username) {
        StringBuilder messages = new StringBuilder("[");
        try (PreparedStatement stmt = connection.prepareStatement("SELECT message FROM messages WHERE username = ?")) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                if (messages.length() > 1) {
                    messages.append(", ");
                }
                messages.append(""").append(rs.getString("message")).append(""");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        messages.append("]");
        return messages.toString();
    }
}
